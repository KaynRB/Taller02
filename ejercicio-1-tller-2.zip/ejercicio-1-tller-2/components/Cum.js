import React from 'react';
import { Text, StyleSheet, View, TouchableHighlight } from 'react-native';
const Cum = ({item, eliminarCum}) => {
const dialogoEliminar = id => {
console.log('eliminando....', id);
eliminarCum(id);
}
return (
<View style={styles.Cum}>
<View>
<Text style={styles.label}>Cumpleanero: </Text>
<Text style={styles.texto}>{item.Cumpleanero}</Text>
</View>
<View>
<Text style={styles.label}>Nota: </Text>
<Text style={styles.texto}>{item.Nota}</Text>
</View>
<View>
<TouchableHighlight onPress={ () => dialogoEliminar(item.id) }
style={styles.btnEliminar}>
<Text style={styles.textoEliminar}> Eliminar &times; </Text>
</TouchableHighlight>
</View>
</View>
)
}
const styles = StyleSheet.create({
cum: {
backgroundColor: '#FFF',
borderBottomColor: '#e1e1e1',
borderStyle: 'solid',
borderBottomWidth: 1,
paddingVertical: 20,
paddingHorizontal: 10
},
label: {
fontWeight: 'bold',
fontSize: 18,
marginTop: 20
},
texto: {
fontSize: 18,
},
btnEliminar: {
padding: 10,
backgroundColor: 'red',
marginVertical: 10
},
textoEliminar: {
color: '#FFF',
fontWeight: 'bold',
textAlign: 'center'
}
})
export default Cum;
