import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const RegisterScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = () => {
   const handleRegister = async () => {
  try {
    const response = await fetch('https://tu-servidor-api.com/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });

    if (!response.ok) {
      throw new Error('Error al registrar usuario');
    }

    const data = await response.json();
    // Aquí puedes manejar la respuesta del servidor
    // Por ejemplo, si el servidor devuelve un mensaje de éxito, puedes mostrar una alerta
    Alert.alert('Registro exitoso', 'Usuario registrado correctamente');
    // Después de registrar correctamente, navega a la pantalla de inicio de sesión
    navigation.navigate('Login');
  } catch (error) {
    console.error('Error al registrar usuario:', error.message);
    // En caso de error, puedes mostrar una alerta o realizar cualquier otra acción necesaria
    Alert.alert('Error', 'Hubo un problema al registrar el usuario. Por favor, intenta nuevamente.');
  }
};

    navigation.navigate('Login');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Registro</Text>
      <TextInput
        style={styles.input}
        placeholder="Nombre de usuario"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Registrar" onPress={handleRegister} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
});

export default RegisterScreen;
