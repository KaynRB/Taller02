import React, { useState, useEffect } from 'react';
import { Text, View, FlatList, TouchableHighlight, TouchableWithoutFeedback, Keyboard, Platform, Button, StyleSheet, Alert, TextInput } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Colors from './src/utils/colors';
import Cita from './components/Cum';
import Formulario from './components/Formulario';

const Stack = createStackNavigator();

// Componente para la pantalla de inicio de sesión
const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (username !== '' && password !== '') {
      const setCustomData = () => {
    const customUsername = 'usuario';
    const customPassword = '123456';
    setUsername(customUsername);
    setPassword(customPassword);
  };
      Alert.alert('Inicio de sesión exitoso');
      navigation.navigate('Appointments'); // Navega a la pantalla de citas después del inicio de sesión
    } else {
      Alert.alert('Error', 'Por favor, ingresa un nombre de usuario y contraseña válidos');
    }
  };




  return (
    <View style={styles.container}>
      <Text style={styles.title}>Inicio de sesión</Text>
      <TextInput
        style={styles.input}
        placeholder="Nombre de usuario"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />
      <Button title="Iniciar sesión" onPress={handleLogin} />
      <Button title="Registrarse" onPress={() => navigation.navigate('Register')} />
    </View>
  );
};

// Componente para la pantalla de registro
const RegisterScreen = ({ navigation }) => {
  // Implementa la funcionalidad de registro aquí
};

// Componente para la pantalla de gestión de citas
const AppointmentsScreen = () => {
  // definir el state de citas
  const [cums, setCums] = useState([]);
  const [mostrarform, guardarMostrarForm] = useState(false);
  
  useEffect(() => {
    const obtenerCumsStorage = async () => {
      try {
        const cumsStorage = await AsyncStorage.getItem('cums');
        if (cumssStorage) {
          setCums(JSON.parse(cumsStorage))
        }
      } catch (error) {
        console.log(error);
      }
    }
    obtenerCumsStorage();
  }, []);
  
  // Elimina los pacientes del state
  const eliminarCum = id => {
    const cumsFiltradas = cums.filter( cum => cum.id !== id );
    setCums( cumsFiltradas );
    guardarCumsStorage(JSON.stringify(cumsFiltradas));
  }
  
  // Muestra u oculta el Formulario
  const mostrarFormulario = () => {
    guardarMostrarForm(!mostrarform);
  }
  
  // Ocultar el teclado
  const cerrarTeclado = () => {
    Keyboard.dismiss();
  }
  
  // Almacenar las citas en storage
  const guardarCumsStorage = async (cumsJSON) => {
    try {
      await AsyncStorage.setItem('cums', cumsJSON);
    } catch (error) {
      console.log(error);
    }
  }
  
  return (
    <TouchableWithoutFeedback onPress={() => cerrarTeclado() }>
      <View style={styles.contenedor}>
        <Text style={styles.titulo}>Administrador</Text>
        <View>
          <TouchableHighlight onPress={ () => mostrarFormulario() } style={styles.btnMostrarForm}>
            <Text style={styles.textoMostrarForm}> {mostrarform ? 'Cancelar' : 'Agregar cumpleañero'} </Text>
          </TouchableHighlight>
        </View>
        <View style={styles.contenido}>
          { mostrarform ? (
            <>
              <Text style={styles.titulo}>Crear Nuevo Cumplenero</Text>
              <Formulario
                cums={cums}
                setCums={setCums}
                guardarMostrarForm={guardarMostrarForm}
                guardarCumsStorage={guardarCumsStorage}
              />
            </>
          ) : (
            <>
              <Text style={styles.titulo}> {cums.length > 0 ? 'Administra ' : 'No hay cumpleñeros'} </Text>
<FlatList
  style={styles.listado}
  data={cums}
  renderItem={ ({item}) => <Cum item={item} eliminarCum={eliminarCum} /> } // Cambio aquí
  keyExtractor={ cum => cum.id}
/>


            </>
          )}
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="Appointments" component={AppointmentsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  contenedor: {
    backgroundColor: Colors.PRIMARY_COLOR,
    flex: 1
  },
  titulo: {
    color: '#FFF',
    marginTop: Platform.OS === 'ios' ? 40 : 20 ,
    marginBottom: 20,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center'
  },
  contenido: {
    flex: 1,
    marginHorizontal: '2.5%',
  },
  listado: {
    flex: 1,
  },
  btnMostrarForm: {
    padding: 10,
    backgroundColor:Colors.BUTTON_COLOR,
    marginVertical: 10
  },
  textoMostrarForm: {
    color: '#FFF',
    fontWeight: 'bold',
    textAlign: 'center'
  }
});

export default App;
